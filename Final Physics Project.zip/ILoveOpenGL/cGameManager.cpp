#include "cGameManager.h"
#include "globalThings.h"

cGameManager::cGameManager() {
}
cGameManager::~cGameManager() {
}

void  cGameManager::movements() {
	

}